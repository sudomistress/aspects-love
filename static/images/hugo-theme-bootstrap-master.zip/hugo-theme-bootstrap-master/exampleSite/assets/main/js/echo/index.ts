import Component from "js/component";

class Echo implements Component {
    run() {
        console.log('message from echo component: assets/main/js/echo/index.ts');
    }
}

export default Echo;
