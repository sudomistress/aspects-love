+++
title = "カテゴリ"
[menu.main]
  parent = "blog"
  weight = 3
  pre = '<i class="fas fa-fw fa-folder me-1"></i>'
+++
