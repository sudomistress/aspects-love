+++
title = "Configuration"
linkTitleIcon = '<i class="fas fa-cog fa-fw"></i>'
navWeight = 980
[menu.footer]
  parent = "docs"
  weight = 2
  pre = '<i class="fas fa-cog fa-fw me-1"></i>'
+++
