+++
title = "Widgets"
linkTitleIcon = '<i class="fas fa-cubes fa-fw"></i>'
aliases = [
  "/en/posts/widgets"
]
navWeight = 700
+++
