---
title: Hugo Authors
description: Hugo is one of the most popular open-source static site generators. With its amazing speed and flexibility, Hugo makes building websites fun again.
social:
  github: gohugoio
  twitter: GoHugoIO
  website: https://gohugo.io/
---
