+++
title = "お問い合わせ"
layout = "contact"
[menu.footer]
  parent = "support"
  weight = 6
  pre = '<i class="fas fa-fw fa-info-circle me-1"></i>'
+++
