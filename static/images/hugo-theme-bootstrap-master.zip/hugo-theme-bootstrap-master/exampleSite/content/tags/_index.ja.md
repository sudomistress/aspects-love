+++
title = "タグ"
[menu.main]
  parent = "blog"
  weight = 4
  pre = '<i class="fas fa-fw fa-tags me-1"></i>'
+++
