+++
title = "よくある質問"
layout = "faq"
[menu.main]
  parent = "support"
  weight = 6
  pre = '<i class="fas fa-fw fa-question-circle me-1"></i>'
[menu.footer]
  parent = "support"
  weight = 6
  pre = '<i class="fas fa-fw fa-question-circle me-1"></i>'
+++
