```bash
$ hugo mod get github.com/razonyang/hugo-theme-bootstrap@[version]
$ hugo mod tidy
$ hugo mod npm pack
$ npm install
$ git add go.mod go.sum package.json package-lock.json
$ git commit -m 'Bump theme to [version]'
```
